﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toys
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What's the manufacturers name?");
            Console.WriteLine("What's the name?");
            Console.WriteLine("What's the price?");
            Console.WriteLine("Any Notes?");

            //I have no idea what this is even asking me to do?
        }
    }
}
