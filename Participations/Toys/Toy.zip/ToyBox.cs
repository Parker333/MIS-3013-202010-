﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toys
{
    class ToyBox
    {
        public string Toy { get; set; }

        public ToyBox()
        {
            //List < string > = new List<Toy>();
        }
    }
}
